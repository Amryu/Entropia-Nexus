using System.Drawing.Imaging;

namespace Skill_Scanner;

public partial class AreaSelect : Form
{
    private Bitmap bitmapPictureBox;
    private Bitmap bitmapScreen;
    private Screen currentScreen;

    public AreaSelect()
    {
        InitializeComponent();

        bitmapPictureBox = new Bitmap(pictureBoxRowImage.Width, pictureBoxRowImage.Height, PixelFormat.Format32bppArgb);
        pictureBoxRowImage.Image = bitmapPictureBox;

        ResetScreen(Screen.FromPoint(MousePosition));
    }

    public Point CalibratedRowOrigin { get; private set; }

    private void UpdatePictureBox()
    {
        var newScreen = Screen.FromPoint(MousePosition);

        if (currentScreen?.DeviceName != newScreen.DeviceName)
        {
            ResetScreen(newScreen);
        }

        var locationOnDesktop = this.PointToScreen(pictureBoxRowImage.Location);
        var locationOnCurrentScreen = new Point(
            locationOnDesktop.X - newScreen.Bounds.X,
            locationOnDesktop.Y - newScreen.Bounds.Y);

        var pictureBoxRectangle = new Rectangle(
            locationOnCurrentScreen.X,
            locationOnCurrentScreen.Y,
            pictureBoxRowImage.Width,
            pictureBoxRowImage.Height);

        CalibratedRowOrigin = locationOnCurrentScreen;

        using (var graphics = Graphics.FromImage(bitmapPictureBox))
        {
            graphics.DrawImage(bitmapScreen, new Rectangle(0, 0, pictureBoxRectangle.Width, pictureBoxRectangle.Height), pictureBoxRectangle, GraphicsUnit.Pixel);
        }

        pictureBoxRowImage.Image = bitmapPictureBox;
    }

    private void ResetScreen(Screen newScreen)
    {
        this.currentScreen = newScreen;

        bitmapScreen = new Bitmap(this.currentScreen.Bounds.Width, this.currentScreen.Bounds.Height, PixelFormat.Format32bppArgb);

        this.Opacity = 0;

        using (var graphics = Graphics.FromImage(bitmapScreen))
        {
            graphics.CopyFromScreen(this.currentScreen.Bounds.X, this.currentScreen.Bounds.Y, 0, 0, bitmapScreen.Size);
        }

        this.Opacity = 1;
    }

    private void AreaSelect_LocationChanged(object sender, EventArgs e)
    {
        UpdatePictureBox();
    }

    private void button1_Click(object sender, EventArgs e)
    {
        this.Close();
    }

    private void AreaSelect_Activated(object sender, EventArgs e)
    {
        ResetScreen(Screen.FromPoint(MousePosition));
    }
}
