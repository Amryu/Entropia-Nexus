﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tesseract;

namespace Skill_Scanner
{
    public partial class Main : Form
    {
        private static readonly Size RowSize = new Size(620, 15);
        private static readonly string[] Ranks = ["Newbie", "Inept", "Poor", "Weak", "Mediocre", "Unskilled", "Green", "Beginner", "Novice", "Amateur", "Apprentice", "Initiated", "Qualified", "Trained", "Able", "Competent", "Adept", "Capable", "Skilled", "Experienced", "Proficient", "Good", "Great", "Inspiring", "Impressive", "Veteran", "Professional", "Specialist", "Advanced", "Remarkable", "Expert", "Exceptional", "Amazing", "Incredible", "Marvelous", "Astonishing", "Outstanding", "Champion", "Elite", "Superior", "Supreme", "Master", "Grand Master", "Arch Master", "Supreme Master", "Ultimate Master", "Great Master", "Great Grand Master", "Great Arch Master", "Great Supreme Master", "Great Ultimate Master", "Entropia Master"];

        private readonly Skill[] skillData;

        private readonly List<SkillRow> SkillRows = new List<SkillRow>();

        private Point firstRowOrigin;
        private bool skillScanActive;
        private System.Windows.Forms.Timer timer;

        private Bitmap bitmapScreen;

        public Main()
        {
            InitializeComponent();

            skillData = JsonSerializer.Deserialize<Skill[]>(new FileStream("skills.json", FileMode.Open));
        }

        struct SkillRow
        {
            public string Name { get; set; }
            public string Rank { get; set; }
            public int Value { get; set; }
        }

        struct Skill
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public SkillProperties? Properties { get; set; }
            public SkillCategory Category { get; set; }
        }

        struct SkillProperties
        {
            public double HpIncrease { get; set; }
            public bool IsHidden { get; set; }
        }

        struct SkillCategory
        {
            public string Name { get; set; }
        }

        private void buttonCalibrate_Click(object sender, EventArgs e)
        {
            var dialog = new AreaSelect();

            dialog.ShowDialog();

            this.firstRowOrigin = dialog.CalibratedRowOrigin;
        }

        private void buttonScan_Click(object sender, EventArgs e)
        {
            if (firstRowOrigin == default)
            {
                MessageBox.Show("Calibrate the skill window location first!");
                return;
            }

            skillScanActive = !skillScanActive;

            if (skillScanActive)
            {
                buttonScan.Text = "Stop Skill Scan";

                var screen = Screen.FromPoint(firstRowOrigin);

                bitmapScreen = new Bitmap(screen.Bounds.Width, screen.Bounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

                SkillRows.Clear();
                listView1.VirtualListSize = 0;

                ScanSkills();

                timer = new System.Windows.Forms.Timer();
                timer.Interval = 100; // Update every 200 ms
                timer.Tick += (s, e) => ScanSkills();
                timer.Start();
            }
            else
            {
                timer?.Stop();

                buttonScan.Text = "Start Skill Scan";
            }
        }

        private void ScanSkills()
        {

            var screen = Screen.FromPoint(firstRowOrigin);

            using (var graphics = Graphics.FromImage(bitmapScreen))
            {
                graphics.CopyFromScreen(screen.Bounds.X, screen.Bounds.Y, 0, 0, screen.Bounds.Size);
            }

            using var engine = new TesseractEngine("./tessdata", "eng", EngineMode.Default, "config.txt");

            engine.SetVariable("tessedit_pageseg_mode", "7"); // Set PSM to 7
            engine.SetVariable("tessedit_ocr_engine_mode", "2"); // Set engine mode to LSTM only
            engine.SetVariable("tessedit_do_osd", "0"); // Disable OSD

            var rowBitmap = new Bitmap(RowSize.Width, RowSize.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            for (var i = 0; i < 12; i++)
            {
                using var graphics = Graphics.FromImage(rowBitmap);

                graphics.DrawImage(
                    bitmapScreen,
                    new Rectangle(0, 0, RowSize.Width, RowSize.Height),
                    new Rectangle(firstRowOrigin.X, firstRowOrigin.Y + 25 * i, RowSize.Width, RowSize.Height),
                    GraphicsUnit.Pixel);

                using var page = engine.Process(rowBitmap);

                var text = page.GetText();
                text = Regex.Replace(text.Trim(), @"\s+", " ");
                var textSegments = text.Split(' ');

                if (textSegments.Length < 2)
                {
                    continue;
                }

                var skill = skillData.MinBy(x => LevenshteinDistance(x.Name.Replace(" ", ""), textSegments[0])).Name;

                if (LevenshteinDistance(skill.Replace(" ", ""), textSegments[0]) > skill.Length / 2)
                {
                    continue;
                }

                if (skill == null)
                {
                    continue;
                }

                if (SkillRows.Any(x => x.Name.Equals(skill, StringComparison.InvariantCultureIgnoreCase)))
                {
                    continue;
                }

                string rank = null;

                if (textSegments.Length > 1 && !int.TryParse(textSegments[1], out var _))
                {
                    rank = Ranks.MinBy(x => LevenshteinDistance(x.Replace(" ", ""), textSegments[1]));

                    if (LevenshteinDistance(rank.Replace(" ", ""), textSegments[1]) > rank.Length / 2) {
                        rank = null;
                    }
                }

                if (!int.TryParse(textSegments[textSegments.Length - 1], out var value))
                {
                    value = 1;
                }

                SkillRows.Add(new SkillRow()
                {
                    Name = skill,
                    Rank = rank ?? "",
                    Value = value
                });

                listView1.VirtualListSize = SkillRows.Count;
            }
        }

        public static int LevenshteinDistance(string source1, string source2)
        {
            var source1Length = source1.Length;
            var source2Length = source2.Length;

            var matrix = new int[source1Length + 1, source2Length + 1];

            // First calculation, if one entry is empty return full length
            if (source1Length == 0)
                return source2Length;

            if (source2Length == 0)
                return source1Length;

            // Initialization of matrix with row size source1Length and columns size source2Length
            for (var i = 0; i <= source1Length; matrix[i, 0] = i++) { }
            for (var j = 0; j <= source2Length; matrix[0, j] = j++) { }

            // Calculate rows and collumns distances
            for (var i = 1; i <= source1Length; i++)
            {
                for (var j = 1; j <= source2Length; j++)
                {
                    var cost = (source2[j - 1] == source1[i - 1]) ? 0 : 1;

                    matrix[i, j] = Math.Min(
                        Math.Min(matrix[i - 1, j] + 1, matrix[i, j - 1] + 1),
                        matrix[i - 1, j - 1] + cost);
                }
            }
            // return result
            return matrix[source1Length, source2Length];
        }
        private void listView1_RetrieveVirtualItem(object sender, RetrieveVirtualItemEventArgs e)
        {
            var skillRow = SkillRows[e.ItemIndex];

            e.Item = new ListViewItem(new string[] { skillRow.Name, skillRow.Rank, skillRow.Value.ToString() });
        }

        private void buttonExport_Click(object sender, EventArgs e)
        {
            var result = saveFileDialog1.ShowDialog();

            if (result == DialogResult.Cancel)
            {
                return;
            }

            var csv = SkillRows
                .Select(x => new string[] { x.Name, x.Value.ToString(), skillData.FirstOrDefault(y => y.Name == x.Name).Category.Name }.Aggregate((a, v) => a + "," + v))
                .Aggregate((a, v) => a + "\n" + v);

            using var stream = saveFileDialog1.OpenFile();

            using var streamWriter = new StreamWriter(stream);

            streamWriter.Write(csv);
            streamWriter.Flush();
        }
    }
}
