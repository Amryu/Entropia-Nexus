﻿namespace Skill_Scanner
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            buttonCalibrate = new Button();
            buttonScan = new Button();
            buttonExport = new Button();
            label1 = new Label();
            listView1 = new ListView();
            columnHeaderName = new ColumnHeader();
            columnHeaderRank = new ColumnHeader();
            columnHeaderValue = new ColumnHeader();
            saveFileDialog1 = new SaveFileDialog();
            SuspendLayout();
            // 
            // buttonCalibrate
            // 
            buttonCalibrate.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonCalibrate.Location = new Point(649, 415);
            buttonCalibrate.Name = "buttonCalibrate";
            buttonCalibrate.Size = new Size(139, 23);
            buttonCalibrate.TabIndex = 0;
            buttonCalibrate.Text = "Calibrate Skill Window";
            buttonCalibrate.UseVisualStyleBackColor = true;
            buttonCalibrate.Click += buttonCalibrate_Click;
            // 
            // buttonScan
            // 
            buttonScan.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            buttonScan.Location = new Point(504, 415);
            buttonScan.Name = "buttonScan";
            buttonScan.Size = new Size(139, 23);
            buttonScan.TabIndex = 1;
            buttonScan.Text = "Start Skill Scan";
            buttonScan.UseVisualStyleBackColor = true;
            buttonScan.Click += buttonScan_Click;
            // 
            // buttonExport
            // 
            buttonExport.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            buttonExport.Location = new Point(12, 415);
            buttonExport.Name = "buttonExport";
            buttonExport.Size = new Size(139, 23);
            buttonExport.TabIndex = 3;
            buttonExport.Text = "Export CSV";
            buttonExport.UseVisualStyleBackColor = true;
            buttonExport.Click += buttonExport_Click;
            // 
            // label1
            // 
            label1.Location = new Point(504, 22);
            label1.Name = "label1";
            label1.Size = new Size(284, 138);
            label1.TabIndex = 4;
            label1.Text = resources.GetString("label1.Text");
            // 
            // listView1
            // 
            listView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeaderName, columnHeaderRank, columnHeaderValue });
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Location = new Point(12, 12);
            listView1.Name = "listView1";
            listView1.Size = new Size(486, 397);
            listView1.TabIndex = 5;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            listView1.VirtualMode = true;
            listView1.RetrieveVirtualItem += listView1_RetrieveVirtualItem;
            // 
            // columnHeaderName
            // 
            columnHeaderName.Text = "Name";
            columnHeaderName.Width = 282;
            // 
            // columnHeaderRank
            // 
            columnHeaderRank.Text = "Rank";
            columnHeaderRank.Width = 100;
            // 
            // columnHeaderValue
            // 
            columnHeaderValue.Text = "Value";
            columnHeaderValue.Width = 100;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listView1);
            Controls.Add(label1);
            Controls.Add(buttonExport);
            Controls.Add(buttonScan);
            Controls.Add(buttonCalibrate);
            Name = "Main";
            Text = "AreaSelect";
            TopMost = true;
            ResumeLayout(false);
        }

        #endregion

        private Button buttonCalibrate;
        private Button buttonScan;
        private Button buttonExport;
        private Label label1;
        private ListView listView1;
        private ColumnHeader columnHeaderName;
        private ColumnHeader columnHeaderRank;
        private ColumnHeader columnHeaderValue;
        private SaveFileDialog saveFileDialog1;
    }
}