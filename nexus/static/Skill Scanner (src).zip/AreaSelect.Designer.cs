﻿namespace Skill_Scanner;

partial class AreaSelect
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        pictureBoxRowImage = new PictureBox();
        button1 = new Button();
        label1 = new Label();
        ((System.ComponentModel.ISupportInitialize)pictureBoxRowImage).BeginInit();
        SuspendLayout();
        // 
        // pictureBoxRowImage
        // 
        pictureBoxRowImage.Location = new Point(12, 12);
        pictureBoxRowImage.Name = "pictureBoxRowImage";
        pictureBoxRowImage.Size = new Size(620, 15);
        pictureBoxRowImage.TabIndex = 0;
        pictureBoxRowImage.TabStop = false;
        // 
        // button1
        // 
        button1.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
        button1.Location = new Point(557, 42);
        button1.Name = "button1";
        button1.Size = new Size(75, 23);
        button1.TabIndex = 1;
        button1.Text = "Confirm";
        button1.UseVisualStyleBackColor = true;
        button1.Click += button1_Click;
        // 
        // label1
        // 
        label1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        label1.AutoSize = true;
        label1.Location = new Point(12, 50);
        label1.Name = "label1";
        label1.Size = new Size(283, 15);
        label1.TabIndex = 2;
        label1.Text = "Place this over the top-most row in the skill window.";
        // 
        // AreaSelect
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(644, 77);
        Controls.Add(label1);
        Controls.Add(button1);
        Controls.Add(pictureBoxRowImage);
        DoubleBuffered = true;
        Name = "AreaSelect";
        Text = "Skill Window Calibration";
        TopMost = true;
        Activated += AreaSelect_Activated;
        LocationChanged += AreaSelect_LocationChanged;
        ((System.ComponentModel.ISupportInitialize)pictureBoxRowImage).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    #endregion

    private PictureBox pictureBoxRowImage;
    private Button button1;
    private Label label1;
}
